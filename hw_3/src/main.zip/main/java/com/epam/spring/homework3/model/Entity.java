package com.epam.spring.homework3.model;

public interface Entity {
    void setId(Long id);
    Long getId();
}

package com.epam.spring.homework3.dto;

public interface EntityDto {
    Long getId();
    void setId(Long id);
}
